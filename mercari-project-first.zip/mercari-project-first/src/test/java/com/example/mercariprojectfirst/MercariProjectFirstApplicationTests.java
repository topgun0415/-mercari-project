package com.example.mercariprojectfirst;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MercariProjectFirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
