package com.example.mercariprojectfirst;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

//mysqlのtableと対応させるマッピング
@Table(name = "MERCARI_TABLE")

public class MercariProjectFirstApplication {

	private final Long id = null;
	private final String name = "";
	private final String email = "";
	private final String role = "";

	public static void main(String[] args) {
		SpringApplication.run(MercariProjectFirstApplication.class, args);
	}

}

//repository interfaceを作成し、DBからdataを取得
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
	List<Employee> findByRole(String role);
}

//controllerクラスを作成し、Rest APIを作成
